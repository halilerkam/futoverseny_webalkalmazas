package com.erkam.runners;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunnersApplicationTests {

	@Test
	void contextLoads() {
	}

}
